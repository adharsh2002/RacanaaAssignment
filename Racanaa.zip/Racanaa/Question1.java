import java.util.HashSet;

public class Question1 {

  // Optimized solution to the problem
  public static boolean optimizedSolution(int[] A, int[] B, int m) {
    int sum_a = sum(A); // Calculate the sum of elements in array A
    int sum_b = sum(B); // Calculate the sum of elements in array B

    // Check if the difference between the sums is even
    if ((sum_b - sum_a) % 2 == 1) {
      return false;
    }

    int targetDifference = (sum_b - sum_a) / 2;

    // Create a set to store elements from both arrays for quick lookup
    HashSet<Integer> set = new HashSet<>();
    for (int num : A) {
      set.add(num);
    }
    for (int num : B) {
      set.add(num);
    }

    // Iterate through array B to find a valid pair for swapping
    for (int num : B) {
      int complement = num - targetDifference;
      if (set.contains(complement)) {
        return true;
      }
    }

    // No valid pair found for swapping
    return false;
  }

  // Helper function to calculate the sum of elements in an array
  private static int sum(int[] array) {
    int result = 0;
    for (int value : array) {
      result += value;
    }
    return result;
  }

  // Main method for testing the optimized solution
  public static void main(String[] args) {
    // Test Case 1
    int[] A1 = { 1, 2, 3 };
    int[] B1 = { 4, 5, 6 };
    int m1 = 6;

    boolean result1 = optimizedSolution(A1, B1, m1);
    System.out.println("Test Case 1: " + result1);

    // Test Case 2
    int[] A2 = { 1, 2, 3 };
    int[] B2 = { 4, 5, 9 };
    int m2 = 6;

    boolean result2 = optimizedSolution(A2, B2, m2);
    System.out.println("Test Case 2: " + result2);

    // Test Case 3
    int[] A3 = { 1, 2, 3 };
    int[] B3 = { 4, 5, 7 };
    int m3 = 6;

    boolean result3 = optimizedSolution(A3, B3, m3);
    System.out.println("Test Case 3: " + result3);
  }
}

// Complexity Analysis:

// Time Complexity:
// -The time complexity of the solution is primarily determined by the
// iterations through arrays A and B.
// -The creation of the HashSet for array A takes O(n) time, where n is the size
// of array A.
// -The subsequent iteration through array B takes O(n) time, where n is the
// size of array B.
// Therefore, the overall time complexity is O(n).

// Space Complexity:
// - The space complexity is influenced by the additional space used by the
// HashSet for array A.
// - The HashSet stores elements from array A, and its space complexity is
// O(min(n, m)), where n is the size of array A and m is the upper limit for the
// values in the arrays.
// - The rest of the algorithm uses a constant amount of space.
// - Therefore, the overall space complexity is O(min(n, m)).

// In summary, the time complexity of the algorithm is O(n), and the space
// complexity is O(min(n, m)).