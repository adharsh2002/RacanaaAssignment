class Node {
  int data;
  Node next;

  public Node(int data) {
    this.data = data;
  }
}

public class Question2 {
  Node head; // Added head node

  public void deleteNode(int key) {
    Node temp = head, prev = null;

    if (temp != null && temp.data == key) {
      head = temp.next; // Update head if deleting the first node
      return;
    }

    while (temp != null && temp.data != key) {
      prev = temp;
      temp = temp.next;
    }

    if (temp == null) {
      return; // Node not found
    }

    prev.next = temp.next;
  }

  public static void main(String[] args) {
    // Example usage
    Question2 list = new Question2();
    list.head = new Node(1);
    list.head.next = new Node(2);
    list.head.next.next = new Node(3);
    list.head.next.next.next = new Node(4);
    list.head.next.next.next.next = new Node(5);

    System.out.println("Original list:");
    list.printList();

    int keyToDelete = 3;
    list.deleteNode(keyToDelete);

    System.out.println("\nList after deleting " + keyToDelete + ":");
    list.printList();
  }

  public void printList() {
    Node current = head;
    while (current != null) {
      System.out.print(current.data + " ");
      current = current.next;
    }
    System.out.println();
  }
}

// Corner Cases:

// Deleting the first node:
// The code correctly handles this by updating the`head`pointer if the node to
// be deleted is the first one.

// Node not found:
// The code gracefully handles the case where the node with the specified key is
// not present in the list, returning without making any modifications.

// Empty list:
// While not explicitly handled in the provided code,it's worth considering that
// attempting to delete a node from an empty list would have no effect.

// Complexity:

// Time Complexity:
// O(n), where n is the number of nodes in the list. In the worst-case scenario,
// the entire list might need to be traversed to find the node to be deleted.

// Space Complexity:
// O(1), as the algorithm only uses a constant amount of extra space (two
// pointers, `temp` and `prev`), regardless of the list size.